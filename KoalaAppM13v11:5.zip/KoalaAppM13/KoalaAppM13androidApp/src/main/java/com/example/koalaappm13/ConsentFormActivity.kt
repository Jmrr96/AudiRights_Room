package com.example.koalaappm13.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ConsentFormViewModel
import com.example.koalaappm13.database.ConsentFormRepository
import androidx.lifecycle.lifecycleScope

class ConsentFormActivity : ComponentActivity() {

    private lateinit var viewModel: ConsentFormViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = AppDatabase.getDatabase(applicationContext, this.lifecycleScope).consentFormDao()
        val repository = ConsentFormRepository(dao)
        viewModel = ConsentFormViewModel(repository)

        setContent {
            ConsentFormScreen(
                viewModel = viewModel,
                onConsentSaved = {
                    finish() // Cuando guardes un consentimiento, vuelves automáticamente atrás
                }
            )
        }
    }
}