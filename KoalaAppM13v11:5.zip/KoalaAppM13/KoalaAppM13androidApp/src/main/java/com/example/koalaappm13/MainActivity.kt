package com.example.koalaappm13

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.ViewModelProvider
import com.example.koalaappm13.database.UserViewModel
import com.example.koalaappm13.database.UserViewModelFactory
import com.example.koalaappm13.ui.ComposeLoginSection

class MainActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var sessionManager: SessionManager
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        sessionManager = SessionManager(this)

        userViewModel = ViewModelProvider(
            this, UserViewModelFactory((application as KoalaApp).userRepository)
        ).get(UserViewModel::class.java)

        findViewById<ComposeView>(R.id.composeView).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                ComposeLoginSection(
                    onLoginClick = { handleLogin() },
                    onForgotPasswordClick = { navigateToRecoverActivity() }
                )
            }
        }
    }

    private fun handleLogin() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (username.isEmpty()) {
            etUsername.error = "El usuario no puede estar vacío"
            return
        }

        if (password.isEmpty()) {
            etPassword.error = "La contraseña no puede estar vacía"
            return
        }

        userViewModel.loginUser(username, password) { user ->
            runOnUiThread {
                if (user != null) {
                    sessionManager.saveUser(user.username, user.username == "admin")

                    Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
                    val intent = if (sessionManager.isAdmin()) {
                        Intent(this, AdminPanelActivity::class.java)
                    } else {
                        Intent(this, HomeActivity::class.java)
                    }
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun navigateToRecoverActivity() {
        startActivity(Intent(this, RecoverActivity::class.java))
    }
}