package com.example.koalaappm13

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "consent_forms")
data class ConsentForm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombrePersona: String,
    val dni: String,
    val fecha: Long, // Guardamos la fecha como timestamp (epoch)
    val descripcionUso: String,
    val firmaPath: String?, // Ruta a la imagen de la firma almacenada localmente
    val usuarioCreador: String, // Username del usuario que generó el consentimiento
    val productionId: Long? = null
)