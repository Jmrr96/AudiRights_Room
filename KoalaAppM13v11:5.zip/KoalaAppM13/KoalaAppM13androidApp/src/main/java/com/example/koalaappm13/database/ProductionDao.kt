package com.example.koalaappm13.database

import androidx.room.*
import com.example.koalaappm13.database.Production
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductionDao {

    @Query("SELECT * FROM production")
    fun getAllProductions(): Flow<List<Production>>

    @Query("SELECT * FROM production WHERE id = :id")
    fun getProductionById(id: Long): Flow<Production?>

    @Insert
    suspend fun insertProduction(production: Production): Long

    @Delete
    suspend fun deleteProduction(production: Production)
}