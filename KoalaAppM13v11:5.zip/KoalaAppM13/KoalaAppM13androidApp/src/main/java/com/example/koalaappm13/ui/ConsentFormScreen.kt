package com.example.koalaappm13.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.MaterialTheme.typography
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.koalaappm13.ConsentForm
import com.example.koalaappm13.database.ConsentFormViewModel
import com.example.koalaappm13.saveBitmapToInternalStorage

@Composable
fun ConsentFormScreen(
    viewModel: ConsentFormViewModel,
    onConsentSaved: () -> Unit
) {
    val context = LocalContext.current
    var nombre by remember { mutableStateOf("") }
    var dni by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var firmaPath by remember { mutableStateOf<String?>(null) }
    val usuarioActual = "admin" // Debería venir del SessionManager.

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        bitmap?.let {
            val path = saveBitmapToInternalStorage(context, it, nombre)
            firmaPath = path
        }
    }

    // Fondo con gradiente similar a tu HomeActivity
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE0E0E0), // gris claro
                        Color.White
                    )
                )
            )
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Nuevo Consentimiento",
                style = typography.h4,
                color = MaterialTheme.colors.primary
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre Completo") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = dni,
                onValueChange = { dni = it },
                label = { Text("DNI") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción del uso") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { launcher.launch(null) },
                colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Capturar Firma", color = Color.White)
            }

            firmaPath?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "✅ Firma capturada",
                    color = Color(0xFF4CAF50),
                    style = typography.subtitle1
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val nuevo = ConsentForm(
                        nombrePersona = nombre,
                        dni = dni,
                        fecha = System.currentTimeMillis(),
                        descripcionUso = descripcion,
                        firmaPath = firmaPath,
                        usuarioCreador = usuarioActual
                    )
                    viewModel.insertConsentForm(nuevo)
                    onConsentSaved()
                },
                enabled = nombre.isNotBlank() && dni.isNotBlank() && descripcion.isNotBlank() && firmaPath != null,
                colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.secondary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar Consentimiento", color = Color.White)
            }
        }
    }
}