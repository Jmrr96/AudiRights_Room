package com.example.koalaappm13.ui.theme

import androidx.compose.ui.graphics.Color

// Define los colores principales
val PrimaryColor = Color(0xFF003366)  // Azul oscuro
val SecondaryColor = Color(0xFF006699)  // Azul intermedio