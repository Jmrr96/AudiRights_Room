package com.example.koalaappm13

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.koalaappm13.database.User
import com.example.koalaappm13.database.UserViewModel
import com.example.koalaappm13.database.UserViewModelFactory

class AddUserActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var etEmail: EditText
    private lateinit var etDni: EditText
    private lateinit var btnAddUser: Button
    private lateinit var userViewModel: UserViewModel
    private lateinit var btnBackToAdmin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_user)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        etEmail = findViewById(R.id.etEmail)
        etDni = findViewById(R.id.etDni)
        btnAddUser = findViewById(R.id.btnAddUser)
        btnBackToAdmin = findViewById(R.id.btnBackToAdmin)

        userViewModel = ViewModelProvider(
            this, UserViewModelFactory((application as KoalaApp).userRepository)
        ).get(UserViewModel::class.java)

        btnAddUser.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val dni = etDni.text.toString().trim()

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || dni.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newUser = User.createUser(username, password, email, dni) // ✅ Se cifra la contraseña antes de guardar

            userViewModel.insertUser(newUser)

            Toast.makeText(this, "Usuario agregado correctamente", Toast.LENGTH_SHORT).show()
            finish()
        }
        btnBackToAdmin.setOnClickListener {
            finish() // Finaliza esta actividad y vuelve automáticamente a AdminPanelActivity
        }
    }
}
