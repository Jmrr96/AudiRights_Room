package com.example.koalaappm13.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.koalaappm13.database.Production
import com.example.koalaappm13.database.ProductionViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProductionListScreen(
    viewModel: ProductionViewModel,
    onProductionSelected: (Long) -> Unit,
    onCreateNew: () -> Unit
) {
    val productions by viewModel.allProductions.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Producciones",
            style = MaterialTheme.typography.h5,
            color = MaterialTheme.colors.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onCreateNew,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary)
        ) {
            Text("Nueva Producción", color = MaterialTheme.colors.onPrimary)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (productions.isEmpty()) {
            Text("No hay producciones registradas.")
        } else {
            LazyColumn {
                items(productions) { production ->
                    ProductionItem(production, onClick = { onProductionSelected(production.id) })
                    Divider()
                }
            }
        }
    }
}

@Composable
fun ProductionItem(production: Production, onClick: () -> Unit) {
    val formatter = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp)
    ) {
        Text(production.nombre, style = MaterialTheme.typography.h6)
        Text("Fecha: ${formatter.format(Date(production.fecha))}")
        Text("Descripción: ${production.descripcion}", style = MaterialTheme.typography.body2)
    }
}