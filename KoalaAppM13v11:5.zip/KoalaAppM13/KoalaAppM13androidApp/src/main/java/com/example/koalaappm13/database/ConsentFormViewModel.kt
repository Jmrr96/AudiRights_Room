package com.example.koalaappm13.database

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.koalaappm13.ConsentForm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow

class ConsentFormViewModel(
    private val repository: ConsentFormRepository
) : ViewModel() {

    val allConsentForms: StateFlow<List<ConsentForm>> = repository.getAllConsentForms()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _formInsertState = MutableStateFlow<Long?>(null)
    val formInsertState: StateFlow<Long?> = _formInsertState

    fun insertConsentForm(form: ConsentForm) {
        viewModelScope.launch {
            val id = repository.insertConsentForm(form)
            _formInsertState.value = id
        }
    }

    fun deleteConsentForm(form: ConsentForm) {
        viewModelScope.launch {
            repository.deleteConsentForm(form)
        }
    }

    fun getConsentFormById(id: Long) = repository.getConsentFormByIdFlow(id)

    fun getConsentFormsForUser(username: String): Flow<List<ConsentForm>> {
        return repository.getConsentFormsByUser(username)
    }

}