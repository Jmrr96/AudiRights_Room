package com.example.koalaappm13

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.koalaappm13.ui.ConsentFormActivity
import com.example.koalaappm13.ui.ConsentListActivity
import com.example.koalaappm13.MainActivity
import com.example.koalaappm13.ProductionListActivity
import com.example.koalaappm13.SessionsActivity
import com.example.koalaappm13.R

class HomeActivity : AppCompatActivity() {

    private lateinit var btnCheckSessions: Button
    private lateinit var btnLogout: Button
    private lateinit var btnNewConsent: Button
    private lateinit var btnManageConsents: Button
    private lateinit var btnCheckProductions: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        btnCheckSessions = findViewById(R.id.btnCheckSessions)
        btnLogout = findViewById(R.id.btnLogout)
        btnNewConsent = findViewById(R.id.btnNewConsent)
        btnManageConsents = findViewById(R.id.btnManageConsents)
        btnCheckProductions = findViewById(R.id.btnCheckProductions)

        btnNewConsent.setOnClickListener {
            startActivity(Intent(this, ConsentFormActivity::class.java))
        }

        btnManageConsents.setOnClickListener {
            val intent = Intent(this, ConsentListActivity::class.java)
            startActivity(intent)
        }

        btnCheckSessions.setOnClickListener {
            val intent = Intent(this, SessionsActivity::class.java)
            startActivity(intent)
        }

        btnCheckProductions.setOnClickListener {
            val intent = Intent(this, ProductionListActivity::class.java)
            startActivity(intent)
        }

        btnLogout.setOnClickListener {
            showLogoutConfirmation()
        }
    }

    private fun showLogoutConfirmation() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Cerrar Sesión")
        builder.setMessage("¿Estás seguro de que quieres cerrar sesión?")
        builder.setPositiveButton("Sí") { _: DialogInterface, _: Int ->
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
        builder.setNegativeButton("No") { dialog: DialogInterface, _: Int ->
            dialog.dismiss()
        }
        builder.show()
    }
}
