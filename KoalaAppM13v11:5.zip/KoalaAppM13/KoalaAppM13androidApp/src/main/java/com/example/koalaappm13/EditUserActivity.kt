package com.example.koalaappm13

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.koalaappm13.database.User
import com.example.koalaappm13.database.UserViewModel
import com.example.koalaappm13.database.UserViewModelFactory

class EditUserActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etDni: EditText
    private lateinit var btnUpdateUser: Button
    private lateinit var userViewModel: UserViewModel
    private var userId: Int = -1
    private var currentPasswordHash: String = ""
    private lateinit var btnBackToAdmin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_user)

        etUsername = findViewById(R.id.etUsername)
        etEmail = findViewById(R.id.etEmail)
        etDni = findViewById(R.id.etDni)
        btnUpdateUser = findViewById(R.id.btnUpdateUser)
        btnBackToAdmin = findViewById(R.id.btnBackToAdmin)

        // ✅ Se usa `userRepository` en lugar de `repository`
        userViewModel = ViewModelProvider(
            this, UserViewModelFactory((application as KoalaApp).userRepository)
        )[UserViewModel::class.java]

        userId = intent.getIntExtra("user_id", -1)

        if (userId != -1) {
            userViewModel.getUserById(userId) { user ->
                runOnUiThread {
                    if (user != null) {
                        etUsername.setText(user.username)
                        etEmail.setText(user.email)
                        etDni.setText(user.dni)
                        currentPasswordHash = user.passwordHash // Guardamos la contraseña original
                    } else {
                        Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }

        btnUpdateUser.setOnClickListener {
            val updatedUser = User(
                id = userId,
                username = etUsername.text.toString(),
                email = etEmail.text.toString(),
                dni = etDni.text.toString(),
                passwordHash = currentPasswordHash // Mantenemos la contraseña actual
            )

            userViewModel.updateUser(updatedUser) {
                Toast.makeText(this, "Usuario actualizado", Toast.LENGTH_SHORT).show()
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
        btnBackToAdmin.setOnClickListener {
            finish() // Finaliza esta actividad y vuelve automáticamente a AdminPanelActivity
        }
    }
}
