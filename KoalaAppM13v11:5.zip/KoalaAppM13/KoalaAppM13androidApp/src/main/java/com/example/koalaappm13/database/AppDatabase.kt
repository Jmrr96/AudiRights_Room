package com.example.koalaappm13.database

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase // ✅ Agregar esta importación
import com.example.koalaappm13.ConsentForm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [User::class, Session::class, ConsentForm::class, Production::class], version = 4, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun sessionDao(): SessionDao
    abstract fun consentFormDao(): ConsentFormDao
    abstract fun productionDao(): ProductionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "koala_database"
                )
                    .fallbackToDestructiveMigration() // ✅ Maneja actualizaciones de esquema sin perder datos
                    .addCallback(DatabaseCallback(scope)) // ✅ Agregamos callback para inicializar admin
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(private val scope: CoroutineScope) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) { // ✅ Ahora está correctamente importado
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.userDao())
                }
            }
        }

        suspend fun populateDatabase(userDao: UserDao) {
            val adminExists = userDao.getUserByUsername("admin") // ✅ Verifica si ya existe
            if (adminExists == null) {
                val adminUser = User(
                    username = "admin",
                    passwordHash = User.hashPassword("admin123"), // ✅ Contraseña cifrada
                    email = "admin@koala.com",
                    dni = "00000000A"
                )
                userDao.insertUser(adminUser)
            }
        }
    }
}
