package com.example.koalaappm13

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.koalaappm13.database.User
import com.example.koalaappm13.database.UserViewModel
import com.example.koalaappm13.database.UserViewModelFactory
import androidx.lifecycle.ViewModelProvider

class AdminPanelActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddUser: Button
    private lateinit var btnLogout: Button
    private lateinit var userAdapter: UserAdapter
    private lateinit var userViewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_panel)

        recyclerView = findViewById(R.id.recyclerViewUsers)
        btnAddUser = findViewById(R.id.btnAddUser)
        btnLogout = findViewById(R.id.btnLogout)

        // ✅ Se usa `userRepository` en lugar de `repository`
        userViewModel = ViewModelProvider(
            this, UserViewModelFactory((application as KoalaApp).userRepository)
        )[UserViewModel::class.java]

        recyclerView.layoutManager = LinearLayoutManager(this)
        userAdapter = UserAdapter(
            emptyList(),
            onDeleteClick = { user -> confirmDeleteUser(user) },
            onEditClick = { user -> editUser(user) }
        )
        recyclerView.adapter = userAdapter

        loadUsers()

        btnAddUser.setOnClickListener {
            addUserLauncher.launch(Intent(this, AddUserActivity::class.java))
        }

        btnLogout.setOnClickListener {
            logout()
        }
    }

    private fun loadUsers() {
        userViewModel.getAllUsers { users: List<User> ->
            runOnUiThread {
                userAdapter.updateUsers(users)
            }
        }
    }

    private fun confirmDeleteUser(user: User) {
        if (user.username == "admin") {
            Toast.makeText(this, "No puedes eliminar al usuario administrador", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Eliminar Usuario")
            .setMessage("¿Estás seguro de que deseas eliminar a ${user.username}? Esta acción no se puede deshacer.")
            .setPositiveButton("Sí") { _, _ ->
                deleteUser(user)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteUser(user: User) {
        userViewModel.deleteUser(user) {
            runOnUiThread {
                Toast.makeText(this, "Usuario eliminado", Toast.LENGTH_SHORT).show()
                loadUsers()
            }
        }
    }

    private fun editUser(user: User) {
        if (user.username == "admin") {
            Toast.makeText(this, "No puedes editar el usuario administrador", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, EditUserActivity::class.java)
        intent.putExtra("user_id", user.id)
        editUserLauncher.launch(intent)
    }

    private fun logout() {
        val sessionManager = SessionManager(this)
        sessionManager.logout()

        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    // ✅ Se reemplaza startActivityForResult por ActivityResultLauncher
    private val addUserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            loadUsers()
        }
    }

    private val editUserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            loadUsers()
        }
    }
}