package com.example.koalaappm13.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "production")
data class Production(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val fecha: Long,
    val descripcion: String
)