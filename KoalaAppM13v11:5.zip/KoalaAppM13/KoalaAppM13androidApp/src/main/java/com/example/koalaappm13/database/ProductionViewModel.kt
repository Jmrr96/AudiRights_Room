package com.example.koalaappm13.database

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProductionViewModel(
    private val repository: ProductionRepository
) : ViewModel() {

    val allProductions: StateFlow<List<Production>> = repository.getAllProductions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun insertProduction(production: Production) {
        viewModelScope.launch {
            repository.insertProduction(production)
        }
    }

    fun getProductionById(id: Long): Flow<Production?> {
        return repository.getProductionById(id)
    }


    fun deleteProduction(production: Production) {
        viewModelScope.launch {
            repository.deleteProduction(production)
        }
    }
}