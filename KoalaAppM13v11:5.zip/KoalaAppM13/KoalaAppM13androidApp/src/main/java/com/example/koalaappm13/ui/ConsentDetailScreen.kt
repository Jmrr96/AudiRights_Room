package com.example.koalaappm13.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.example.koalaappm13.ConsentForm
import java.io.File

@Composable
fun ConsentDetailScreen(
    consentForm: ConsentForm,
    onDelete: () -> Unit,
    onExport: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colors.primary.copy(alpha = 0.1f),
                        MaterialTheme.colors.background
                    )
                )
            )
            .padding(20.dp)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            elevation = 8.dp,
            backgroundColor = MaterialTheme.colors.surface,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Detalle del Consentimiento",
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.primary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Nombre: ${consentForm.nombrePersona}", style = MaterialTheme.typography.h6)
                Spacer(modifier = Modifier.height(8.dp))

                Text("DNI: ${consentForm.dni}", style = MaterialTheme.typography.body1)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Descripción:", style = MaterialTheme.typography.subtitle1)
                Text(consentForm.descripcionUso, style = MaterialTheme.typography.body2)
                Spacer(modifier = Modifier.height(16.dp))

                consentForm.firmaPath?.let { path ->
                    val file = File(path)
                    if (file.exists()) {
                        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                        bitmap?.let {
                            Image(
                                bitmap = it.asImageBitmap(),
                                contentDescription = "Firma",
                                modifier = Modifier
                                    .height(180.dp)
                                    .fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { onExport() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.primary)
                ) {
                    Text("Exportar Firma", color = MaterialTheme.colors.onPrimary)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onDelete() },
                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
                ) {
                    Text("Eliminar Consentimiento", color = MaterialTheme.colors.onError)
                }

            }
        }
    }
}