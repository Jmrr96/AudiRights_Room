package com.example.koalaappm13.database

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class UserViewModel(private val repository: UserRepository) : ViewModel() {

    // ✅ Insertar usuario en la base de datos
    fun insertUser(user: User) {
        viewModelScope.launch {
            repository.insertUser(user)
        }
    }

    // ✅ Obtener todos los usuarios
    fun getAllUsers(callback: (List<User>) -> Unit) {
        viewModelScope.launch {
            val users = repository.getAllUsers() // 🔹 Llamada corregida
            callback(users)
        }
    }

    // ✅ Eliminar usuario
    fun deleteUser(user: User, callback: () -> Unit) {
        viewModelScope.launch {
            repository.deleteUser(user) // 🔹 Llamada corregida
            callback()
        }
    }

    // ✅ Actualizar usuario
    fun updateUser(user: User, callback: () -> Unit) {
        viewModelScope.launch {
            repository.updateUser(user) // 🔹 Llamada corregida
            callback()
        }
    }

    // ✅ Login del usuario
    fun loginUser(username: String, password: String, callback: (User?) -> Unit) {
        viewModelScope.launch {
            val user = repository.loginUser(username, password) // 🔹 Llamada corregida
            callback(user)
        }
    }

    // ✅ Recuperar usuario por email y DNI
    fun findUserByEmailAndDni(email: String, dni: String, callback: (User?) -> Unit) {
        viewModelScope.launch {
            val user = repository.findUserByEmailAndDni(email, dni) // 🔹 Llamada corregida
            callback(user)
        }
    }

    // ✅ Obtener usuario por ID
    fun getUserById(userId: Int, callback: (User?) -> Unit) {
        viewModelScope.launch {
            val user = repository.getUserById(userId) // 🔹 Llamada corregida
            callback(user)
        }
    }
}
