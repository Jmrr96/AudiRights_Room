package com.example.koalaappm13.database

import kotlinx.coroutines.flow.Flow

class ProductionRepository(private val productionDao: ProductionDao) {

    fun getAllProductions(): Flow<List<Production>> = productionDao.getAllProductions()

    suspend fun insertProduction(production: Production): Long {
        return productionDao.insertProduction(production)
    }

    // ProductionRepository.kt
    fun getProductionById(id: Long): Flow<Production?> {
        return productionDao.getProductionById(id)
    }

    suspend fun deleteProduction(production: Production) {
        productionDao.deleteProduction(production)
    }
}