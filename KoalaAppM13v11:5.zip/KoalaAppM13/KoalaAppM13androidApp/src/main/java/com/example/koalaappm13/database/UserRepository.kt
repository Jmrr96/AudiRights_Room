package com.example.koalaappm13.database

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UserRepository(private val userDao: UserDao, private val sessionDao: SessionDao) {

    // ✅ Insertar usuario en la base de datos (cifrando la contraseña correctamente)
    suspend fun insertUser(user: User) {
        val hashedUser = if (user.passwordHash.length != 64) { // Evita volver a cifrar un hash
            user.copy(passwordHash = User.hashPassword(user.passwordHash))
        } else {
            user // Ya está cifrado
        }
        withContext(Dispatchers.IO) {
            userDao.insertUser(hashedUser)
        }
    }

    // ✅ Obtener todos los usuarios
    suspend fun getAllUsers(): List<User> {
        return withContext(Dispatchers.IO) {
            userDao.getAllUsers()
        }
    }

    // ✅ Eliminar usuario
    suspend fun deleteUser(user: User) {
        withContext(Dispatchers.IO) {
            userDao.deleteUser(user)
        }
    }

    // ✅ Actualizar usuario sin modificar su contraseña si ya está encriptada
    suspend fun updateUser(user: User) {
        val hashedUser = if (user.passwordHash.isNotEmpty()) user else user.copy(passwordHash = User.hashPassword("defaultPassword"))
        withContext(Dispatchers.IO) {
            userDao.updateUser(hashedUser)
        }
    }

    // ✅ Iniciar sesión
    suspend fun loginUser(username: String, password: String): User? {
        return withContext(Dispatchers.IO) {
            val user = userDao.loginUser(username)
            if (user != null && user.verifyPassword(password)) {
                val session = Session(username = user.username, timestamp = System.currentTimeMillis())
                sessionDao.insertSession(session) // Registrar sesión
                user
            } else {
                null
            }
        }
    }

    // ✅ Buscar usuario por email y DNI
    suspend fun findUserByEmailAndDni(email: String, dni: String): User? {
        return withContext(Dispatchers.IO) {
            userDao.findUserByEmailAndDni(email, dni)
        }
    }

    // ✅ Obtener usuario por ID
    suspend fun getUserById(userId: Int): User? {
        return withContext(Dispatchers.IO) {
            userDao.getUserById(userId)
        }
    }

    // ✅ Obtener usuario por nombre de usuario
    suspend fun getUserByUsername(username: String): User? {
        return withContext(Dispatchers.IO) {
            userDao.getUserByUsername(username)
        }
    }
}
