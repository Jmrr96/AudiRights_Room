package com.example.koalaappm13.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.example.koalaappm13.ConsentDetailActivity
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ConsentFormRepository
import com.example.koalaappm13.database.ConsentFormViewModel


class ConsentListActivity : ComponentActivity() {

    private lateinit var viewModel: ConsentFormViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializamos el ViewModel y repositorio
        val dao = AppDatabase.getDatabase(applicationContext, lifecycleScope).consentFormDao()
        val repository = ConsentFormRepository(dao)
        viewModel = ConsentFormViewModel(repository)

        val prefs = getSharedPreferences("user_session", MODE_PRIVATE)
        val currentUsername = prefs.getString("username", "") ?: ""

        setContent {
            KoalaAppM13Theme {
                val consentForms by viewModel.getConsentFormsForUser(currentUsername).collectAsState(initial = emptyList())

                ConsentListScreen(
                    consentForms = consentForms,
                    viewModel = viewModel,
                    onConsentSelected = { consentId ->
                        val intent = Intent(this, ConsentDetailActivity::class.java)
                        intent.putExtra("consent_id", consentId)
                        startActivity(intent)
                    }
                )
            }
        }
    }
}