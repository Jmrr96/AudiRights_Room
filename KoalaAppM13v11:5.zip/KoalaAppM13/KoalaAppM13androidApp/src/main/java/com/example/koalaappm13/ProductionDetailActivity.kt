package com.example.koalaappm13

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.lifecycleScope
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ProductionRepository
import com.example.koalaappm13.database.ProductionViewModel
import com.example.koalaappm13.ui.KoalaAppM13Theme
import com.example.koalaappm13.ui.ProductionDetailScreen
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.koalaappm13.database.Production
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProductionDetailActivity : ComponentActivity() {

    private lateinit var viewModel: ProductionViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val productionId = intent.getLongExtra("production_id", -1)
        val dao = AppDatabase.getDatabase(applicationContext, lifecycleScope).productionDao()
        val repository = ProductionRepository(dao)
        viewModel = ProductionViewModel(repository)

        setContent {
            KoalaAppM13Theme {
                if (productionId != -1L) {
                    // Usamos collectAsState en un efecto para suspender y obtener los datos
                    var loaded by remember { mutableStateOf(false) }
                    var production by remember { mutableStateOf<Production?>(null) }

                    LaunchedEffect(true) {
                        viewModel.getProductionById(productionId).collectLatest {
                            production = it
                            loaded = true
                        }
                    }

                    if (loaded && production != null) {
                        ProductionDetailScreen(
                            production = production!!,
                            onDelete = {
                                lifecycleScope.launch {
                                    viewModel.deleteProduction(production!!)
                                    Toast.makeText(this@ProductionDetailActivity, "Producción eliminada", Toast.LENGTH_SHORT).show()
                                    finish()
                                }
                            }
                        )
                    } else {
                        Toast.makeText(this, "Producción no encontrada", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } else {
                    Toast.makeText(this, "ID de producción inválido", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}


