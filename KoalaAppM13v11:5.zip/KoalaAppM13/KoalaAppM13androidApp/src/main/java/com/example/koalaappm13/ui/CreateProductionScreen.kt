package com.example.koalaappm13.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.koalaappm13.database.Production
import com.example.koalaappm13.database.ProductionViewModel

@Composable
fun CreateProductionScreen(
    viewModel: ProductionViewModel,
    onSaved: () -> Unit
) {
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
    ) {
        Text("Nueva Producción", style = MaterialTheme.typography.h5)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre de la producción") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = descripcion,
            onValueChange = { descripcion = it },
            label = { Text("Descripción") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (nombre.isNotBlank() && descripcion.isNotBlank()) {
                    val nueva = Production(
                        nombre = nombre,
                        descripcion = descripcion,
                        fecha = System.currentTimeMillis()
                    )
                    viewModel.insertProduction(nueva)
                    onSaved()
                }
            },
            enabled = nombre.isNotBlank() && descripcion.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar Producción")
        }
    }
}