package com.example.koalaappm13

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SessionsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: SessionsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sessions)

        recyclerView = findViewById(R.id.recyclerViewSessions)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Simulando datos de sesiones
        val sessionsList = listOf(
            "Inicio de sesión: 2024-02-01 10:30 AM",
            "Inicio de sesión: 2024-02-02 02:15 PM",
            "Inicio de sesión: 2024-02-03 09:45 AM"
        )

        adapter = SessionsAdapter(sessionsList)
        recyclerView.adapter = adapter
    }
}
