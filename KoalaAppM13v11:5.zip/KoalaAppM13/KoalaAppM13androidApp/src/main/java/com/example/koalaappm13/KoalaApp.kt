package com.example.koalaappm13

import android.app.Application
import com.example.koalaappm13.database.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class KoalaApp : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob())

    lateinit var userRepository: UserRepository
    lateinit var sessionRepository: SessionRepository
    lateinit var consentFormRepository: ConsentFormRepository

    override fun onCreate() {
        super.onCreate()

        val database = AppDatabase.getDatabase(this, applicationScope)
        userRepository = UserRepository(database.userDao(), database.sessionDao())
        sessionRepository = SessionRepository(database.sessionDao())
        consentFormRepository = ConsentFormRepository(database.consentFormDao())

    }
}