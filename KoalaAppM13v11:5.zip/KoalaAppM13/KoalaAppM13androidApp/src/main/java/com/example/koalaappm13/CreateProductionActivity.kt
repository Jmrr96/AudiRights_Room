package com.example.koalaappm13

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ProductionRepository
import com.example.koalaappm13.database.ProductionViewModel
import com.example.koalaappm13.ui.CreateProductionScreen
import com.example.koalaappm13.ui.KoalaAppM13Theme

class CreateProductionActivity : ComponentActivity() {

    private lateinit var viewModel: ProductionViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = AppDatabase.getDatabase(applicationContext, lifecycleScope).productionDao()
        val repository = ProductionRepository(dao)
        viewModel = ProductionViewModel(repository)

        setContent {
            KoalaAppM13Theme {
                CreateProductionScreen(
                    viewModel = viewModel,
                    onSaved = {
                        Toast.makeText(this, "Producción guardada", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                )
            }
        }
    }
}