package com.example.koalaappm13

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ConsentFormRepository
import com.example.koalaappm13.database.ConsentFormViewModel
import com.example.koalaappm13.ui.ConsentDetailScreen
import com.example.koalaappm13.ui.KoalaAppM13Theme
import kotlinx.coroutines.launch
import java.io.File

class ConsentDetailActivity : ComponentActivity() {

    private lateinit var viewModel: ConsentFormViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val consentId = intent.getLongExtra("consent_id", -1)

        // Crea el ViewModel manualmente
        val dao = AppDatabase.getDatabase(applicationContext, lifecycleScope).consentFormDao()
        val repository = ConsentFormRepository(dao)
        viewModel = ConsentFormViewModel(repository)

        setContent {
            KoalaAppM13Theme {
                if (consentId != -1L) {
                    val consentForm by viewModel.getConsentFormById(consentId).collectAsState(initial = null)

                    consentForm?.let { form ->
                        ConsentDetailScreen(
                            consentForm = form,
                            onDelete = {
                                lifecycleScope.launch {
                                    viewModel.deleteConsentForm(form)
                                    Toast.makeText(this@ConsentDetailActivity, "Consentimiento eliminado", Toast.LENGTH_SHORT).show()
                                    finish()
                                }
                            },
                            onExport = {
                                form.firmaPath?.let { path ->
                                    val file = File(path)
                                    if (file.exists()) {
                                        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                                        val success = exportImageToGallery(this, bitmap, "firma_${form.nombrePersona}.png")
                                        val msg = if (success) "Firma exportada con éxito" else "Error al exportar firma"
                                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        )
                    } ?: Text("Consentimiento no encontrado")
                } else {
                    Text("Error cargando consentimiento")
                }
            }
        }
    }
}