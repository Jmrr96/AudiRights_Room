package com.example.koalaappm13

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.koalaappm13.database.AppDatabase
import com.example.koalaappm13.database.ProductionRepository
import com.example.koalaappm13.database.ProductionViewModel
import com.example.koalaappm13.ui.KoalaAppM13Theme
import com.example.koalaappm13.ui.ProductionListScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProductionListActivity : ComponentActivity() {

    private lateinit var viewModel: ProductionViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = AppDatabase.getDatabase(applicationContext, lifecycleScope).productionDao()
        val repository = ProductionRepository(dao)

        viewModel = ProductionViewModel(repository)

        setContent {
            KoalaAppM13Theme {
                ProductionListScreen(
                    viewModel = viewModel,
                    onProductionSelected = { productionId ->
                        val intent = Intent(this, ProductionDetailActivity::class.java)
                        intent.putExtra("production_id", productionId)
                        startActivity(intent)
                    },
                    onCreateNew = {
                        val intent = Intent(this, CreateProductionActivity::class.java)
                        startActivity(intent)
                    }
                )
            }
        }
    }
}