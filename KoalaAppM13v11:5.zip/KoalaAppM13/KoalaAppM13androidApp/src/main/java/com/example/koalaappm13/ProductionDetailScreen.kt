package com.example.koalaappm13.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.koalaappm13.database.Production
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProductionDetailScreen(
    production: Production,
    onDelete: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = 8.dp,
        modifier = Modifier
            .padding(20.dp)
            .fillMaxSize()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text("Detalle de Producción", style = MaterialTheme.typography.h5)
            Spacer(modifier = Modifier.height(16.dp))

            Text("Nombre: ${production.nombre}", style = MaterialTheme.typography.h6)
            Spacer(modifier = Modifier.height(8.dp))

            Text("Descripción:", style = MaterialTheme.typography.subtitle1)
            Text(production.descripcion, style = MaterialTheme.typography.body1)
            Spacer(modifier = Modifier.height(8.dp))

            Text("Fecha: ${dateFormat.format(Date(production.fecha))}", style = MaterialTheme.typography.caption)

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { onDelete() },
                colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.error)
            ) {
                Text("Eliminar Producción", color = MaterialTheme.colors.onError)
            }
        }
    }
}