package com.example.koalaappm13.database

import androidx.room.*

@Dao
interface UserDao {

    // Obtener todos los usuarios
    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<User>

    // Insertar usuario en la base de datos
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    // Verificar usuario por username (sin incluir password en la consulta)
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun loginUser(username: String): User?

    // Buscar usuario por email y DNI
    @Query("SELECT * FROM users WHERE email = :email AND dni = :dni LIMIT 1")
    suspend fun findUserByEmailAndDni(email: String, dni: String): User?

    // Obtener usuario por ID
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): User?

    // ✅ Obtener usuario por nombre de usuario
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): User? // 🔹 Se añade esta consulta

    // Eliminar usuario
    @Delete
    suspend fun deleteUser(user: User)

    // Actualizar usuario
    @Update
    suspend fun updateUser(user: User)
}
