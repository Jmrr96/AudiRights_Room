package com.example.koalaappm13.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.security.MessageDigest

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val passwordHash: String, // ✅ Se requiere que la contraseña esté siempre cifrada
    val email: String,
    val dni: String
) {
    fun verifyPassword(password: String): Boolean {
        return passwordHash.isNotEmpty() && hashPassword(password) == passwordHash
    }

    companion object {
        fun hashPassword(password: String): String {
            val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
            return bytes.joinToString("") { "%02x".format(it) }
        }

        // ✅ Función para crear usuario asegurando que la contraseña siempre esté cifrada
        fun createUser(username: String, password: String, email: String, dni: String): User {
            val hashedPassword = if (password.isNotEmpty()) hashPassword(password) else hashPassword("defaultPassword")
            return User(
                username = username,
                passwordHash = hashedPassword, // ✅ Se cifra antes de ser guardada
                email = email,
                dni = dni
            )
        }
    }
}
